#include "Scheduler.h"
#include"Processor.h"
#include"LinkedQueue.h"
#include<fstream>
#include <cstdlib>
#include <random>
#include <vector>
Scheduler::Scheduler()
{
    //fill new
    TimeSlice = 0;
    TimeStep = 1; //starts from 1??
    //loaded from input file
    processor = new Processor * [200]; //revise dynamic allocation
    //Running = new Process * [RUNCount];
    //array of pointers to processors?
    pntrToUI = NULL;
    RUNCount = 0;
    BLKCount = 0;
    TRMCount = 0;
    ForkProbability = 0;
    WTSUM = 0; 
    RTSUM = 0; 
    TRTSUM = 0;
    IO_DCount = 0;
    sleep = 0;
}

void Scheduler::AddNew(Process* p)
{
    New.enqueue(p);
}

bool Scheduler::MoveToRDY(int Processorid)
//need process count? for loop or while?
//corner cases?
//shortest queue thing???
{
   // for(int j=0;j<NumberOfProcesses;j++)
   // {
    Process* temp; //? parameters bt3tha eh? 
    if (!New.isEmpty())
    {
        New.dequeue(temp);
        processor[Processorid]->EnqueueReady(temp);
        return true;
        //  for (int i = 1; i < NumberOfProcesses+1; i++)
          //
              //if (i == (NF + NS + NR) + 1)
                 // i = 1;
         // }
    }
    else return false;
    // }
     //if (!New.isEmpty())
     //{
         //New.peek(temp);
        // if (temp->getAT() == TimeStep)
        // {
     //        New.dequeue(temp); //????
     //        for (int i = 0; i <= (NF + NS + NR); i++)
     //        {
     //            if (!New.isEmpty())
     //            {
     //        processor[Processorid]->EnqueueReady(temp); //how are they distributed amongst the 3 processors??
     //    }
     //}
     //    }
     ////}
     //}
     //New.dequeue(); what is it's parameter i simply want it to dequeue it's first element****
}

int Scheduler::ChosenRDYList()
{
    int check = 0;
    int ShortestIndex = 1;
    Processor* temp = processor[1];
    for (int i = 1; i < ((NF + NS + NR)); i++)
    {
        if (processor[i + 1]->getExpectedFinishTime() < temp->getExpectedFinishTime())
        {
            ShortestIndex = i+1;
            temp = processor[ShortestIndex];
        }
    }
    return ShortestIndex;
        // MoveToRDY(ShortestIndex);
}

int Scheduler::ShortestFCFS()
{
    int ShortestIndex = 1;
    Processor* temp = processor[1];
    for (int i = 1; i < NF; i++)
    {
        if (processor[i + 1]->getExpectedFinishTime() < temp->getExpectedFinishTime())
        {
            ShortestIndex = i + 1;
            temp = processor[ShortestIndex];
        }
    }
    return ShortestIndex;
}

void Scheduler::ShortestSJF()
{
    int ShortestIndex = NF+1;
    Processor* temp = processor[ShortestIndex];
    for (int i = (NF+1); i < ((NF + NS)); i++)
    {
        if (processor[i + 1]->getExpectedFinishTime() < temp->getExpectedFinishTime())
        {
            ShortestIndex = i + 1;
            temp = processor[ShortestIndex];
        }
    }
}

void Scheduler::ShortestRR()
{
    int ShortestIndex = NF+NS+1;
    Processor* temp = processor[ShortestIndex];
    for (int i= (NS+NF+ 1); i < (NR + NF + NS); i++)
    {
        if (processor[i + 1]->getExpectedFinishTime() < temp->getExpectedFinishTime())
        {
            ShortestIndex = i + 1;
            temp = processor[ShortestIndex];
        }
    }
}

void Scheduler::MoveToBLK(Process* p)
{
    //enqueue pointers not objects
   // if(processor[id]->getRun()!=NULL)
    BLK.enqueue(p);
}

void Scheduler::MoveToTRM(Process* b)
{
    TRM.enqueue(b);
    b->setTT(TimeStep);
   // RUNCount--; //**
   // TRMCount++;//**
}

void Scheduler::DecrementTRM()
{
    TRMCount--;
}

void Scheduler::DecrementTimeSlice()
{
    TimeSlice--;
}

int Scheduler::random()
{
    random_device rd;
    mt19937 gen(rd()); 
    uniform_int_distribution<> dis(1, 100);
    return dis(gen);

}

void Scheduler::Simulate()
{
    Load();
    //fill new list of processes in load after creating them.
    CreateProcessor();
    int count = 1; //for processorid in movetordy function
    while (!IsTerminated()) {
        for (int i = 1; i < NumberOfProcesses+1; i++)
        {
            if (MoveToRDY(count))
            {
                count++;
                if (count > (NF + NS + NR))
                {
                    count = 1;
                }
            }
            //if(processor[i]->getArrivalTime()==TimeStep)
            if (count == NumberOfProcesses + 1)
            {
                break;
            }
            // bool x=MoveToRDY(count);
            //count++;
            //if (count>=(NF + NS + NR))
            //{
            //   /* if(count< NumberOfProcesses + 1) {
            //        count = 1;
            //    }*/
            //}
        }
        for (int j = 1; j < (NF + NS + NR) + 1; j++)
        {
            if (processor[j]->getSchedulingState() != 0)
                continue;
            processor[j]->MoveToRun();
        }
        for (int i = 1; i < (NF + NS + NR) + 1; i++)
        {
            if (processor[i]->getRun() != NULL) //while
            {
                if (processor[i]->getRun()->getCT() == 0)
                {
                    MoveToTRM(processor[i]->getRun());
                    processor[i]->setRun(NULL);
                    processor[i]->setSchedulingState(0);
                    RUNCount--;
                    TRMCount++;
                }
               /* else {
                    int x = random();
                    if (x >= 1 && x <= 15)
                    {
                        MoveToBLK(processor[i]->getRun());
                        processor[i]->setRun(NULL);
                        processor[i]->setSchedulingState(0);
                        RUNCount--;
                        BLKCount++;
                        break;
                    }
                    if (x >= 20 && x <= 30)
                    {
                        MoveToRDY(i);
                        processor[i]->setRun(NULL);
                        processor[i]->setSchedulingState(0);
                        processor[i]->IncrementRDY();
                        break;
                    }
                    if (x >= 50 && x <= 60)
                    {
                        MoveToTRM(processor[i]->getRun());
                        processor[i]->setRun(NULL);
                        processor[i]->setSchedulingState(0);
                        break;
                    }*/
                    if (processor[i]->getRun() != NULL)
                    {
                        processor[i]->getRun()->DecrementCT();
                        break;
                        //zqafunction in process
                    }
                    //}
               
            }
            //int Probability = random(); //iv
            //if (Probability < 10)
            //{
            //    Process* temp; //?
            //    BLK.dequeue(temp);
            //    srand(time(0));
            //    int x = (0 + ((NF + NS + NR) - 0)) * rand();
            //    if (x <= (NF + NS + NR))
            //    {
            //        processor[x]->EnqueueReady(temp);
            //        BLKCount--;
            //        processor[x]->IncrementRDY();
            //    }
            //}
            //for (int i = 0; i < NF; i++)
            //{
            //    int rand = random();
            //    Process *p;
            //    if (rand <= NF)
            //    {
            //        p=processor[rand]->dequeueRDY();
            //        if (p != NULL) {
            //            processor[rand]->DecrementRDY();
            //            TRM.enqueue(p);
            //            TRMCount++;
            //        }
            //        //NF--;
            //    }
            //}


        }
        pntrToUI->InteractivePrint(TimeStep, processor, NF, NS, NR, BLK, BLKCount, TRM, TRMCount, RUNCount, Running);
        TimeStep++;
    }
    //    int numNewProcesses = generateRandomNumber();
    //    for (int i = 0; i < numNewProcesses; i++) {
    //        Process* newProcess = new Process(getchildID(), timestep);
    //        addToNewList(newProcess);
    //        incrementchildID();
    //    }

    //    // Add processes from the new list to the ready lists
    //    addProcessesToReadyLists(timestep);

    //    // Check for any blocked processes that have completed their I/O operations
    //    checkBlockedProcesses(timestep);

    //    // Schedule processes for execution
    //    scheduleProcesses(timestep);

    //    // Print the current state of the system
    //    cout << "Timestep " << timestep << ":" << endl;
    //    cout << "============================================" << endl;
    //    printProcessorList();
    //    printReadyLists();
    //    printBlockedList();
    //    printTerminatedList();
    //    cout << "============================================" << endl << endl;

    //    timestep++;

    //    // Check if all processes have terminated
    //    allIsTerminated = checkAllProcessesTerminated();
    //}
}
void Scheduler::Simulate2()
{
    int x=pntrToUI->Pick();
    Load();
    //fill new list of processes in load after creating them.
    CreateProcessor();
    int index;
    while (!IsTerminated()) {
        for (int i = 1; i < NumberOfProcesses + 1; i++)
        {
            index=ChosenRDYList();
            MoveToRDY(index);
        }
        for (int j = 1; j < (NF + NS + NR) + 1; j++)
        {
           // if (processor[j]->getSchedulingState() != 0)
                //continue;
             processor[j]->SchedulingAlgo();
        }
        //for (int i = 1; i < (NF + NS + NR) + 1; i++)
        //{
        //    if (processor[i]->getRun() != NULL) //while
        //    {
        //    }
            //srand(time(0));
            //int Probability = (rand() % 100) + 1; //iv
            //if (Probability < 10)
            //{
            //    Process* temp; //?
            //    BLK.dequeue(temp);
            //    srand(time(0));
            //    int x = (0 + ((NF + NS + NR) - 0)) * rand();
            //    if (x <= (NF + NS + NR))
            //    {
            //        processor[x]->EnqueueReady(temp);
            //        BLKCount--;
            //        processor[x]->IncrementRDY();
            //    }
            //}
            //for (int i = 0; i < NF; i++)
            //{
            //    srand(time(0));
            //    int random = (rand() % 10) + 1;
            //    Process* p;
            //    if (random <= NF)
            //    {
            //        p = processor[random]->dequeueRDY();
            //        if (p != NULL) {
            //            processor[random]->DecrementRDY();
            //            TRM.enqueue(p);
            //            TRMCount++;
            //        }
            //        //NF--;
               // }
            //}
        KILLSIG();

       // }
        ChooseInterface(x); //** 
        TimeStep++;
    }
    if (x == 3)
    {
       // pntrToUI->SilentPrint();
        sleep = 1;
    }
    if (sleep == 1)
    {
        pntrToUI->SilentPrint();
    }
}

void Scheduler::IncrementBLKCount()
{
    BLKCount++;
}

void Scheduler::DecrementRUN()
{
    RUNCount--;
}

int Scheduler::getTimeSlice()
{
    return TimeSlice;
}

void Scheduler::ChooseInterface(int x)
{
    if (x == 1)
    {
        pntrToUI->InteractivePrint(TimeStep, processor, NF, NS, NR, BLK, BLKCount, TRM, TRMCount, RUNCount, Running);
    }
    else if (x == 2)
    {
        pntrToUI->StepByStepPrint(TimeStep, processor, NF, NS, NR, BLK, BLKCount, TRM, TRMCount, RUNCount, Running);
    }
    else if (x == 3)
    {
        return;
       /* pntrToUI->SilentPrint();
        Output();*/
    }
}

void Scheduler::IncrementTRM()
{
    TRMCount++;
}


void Scheduler::testTRM()
{
    int b = TRMCount;
    Process* a;
    //while (b)
    //{
        TRM.Print();
       // TRM.dequeue(a);
       // b--;
   // }
}

void Scheduler::RUNtoBLK(Process*a)
{
    if (a != NULL)
    {
        BLK.enqueue(a);
        IncrementBLKCount();
        BLKtoRDY();
    }
    //if (processor[id]->getRun() != NULL) {
    //    /*if (IO == 0)
    //    {
    //        int IO = Run->getIO_R();
    //    }*/
    //    //int IO2 = Run->getIO_R();
    //    if (processor[id]->getRun()->getN() != 0 && processor[id]->getRun()->getIO_R(1) <= TimeSlice)
    //    {
    //        processor[id]->getRun()->IncrementCount();
    //        processor[id]->getRun()->DecrementCT();
    //        //if (Run->getCount()==IO)
    //        //{
    //        //	Run->DecrementCount();
    //        //	//ptr->DecrementTimeSlice() 
    //        //	return;
    //        //}

    //        if (processor[id]->getRun()->getCount() == processor[id]->getRun()->getIO_R(1))
    //        {
    //            MoveToTRM(processor[id]->getRun());
    //            IncrementTRM();
    //            //incrementblkcount
    //            //pntr->IncrementTRM();
    //            processor[id]->getRun()->getIO_R(0);
    //            processor[id]->getRun()->DecrementN();
    //            processor[id]->setRun(NULL);
    //            processor[id]->setSchedulingState(false);
    //            //decrement runcount
    //            DecrementRUN();
    //            return;

    //        }
    //    }
    //}

}
void Scheduler::BLKtoRDY() //i need the shortest rdy
{
    if (BLK.isEmpty())
    {
        return;
    }
    else
    {
        while (!BLK.isEmpty())
        {
            Process* id;
            BLK.peek(id);
            while (IO_DCount != id->getIO_D(1))
            {
                IO_DCount++;
                return;

            }
            if (IO_DCount == id->getIO_D(1))
            {
                int z;
                BLK.dequeue(id);
                BLKCount--;
                z=ChosenRDYList();
                processor[z]->EnqueueReady(id);
                id->getIO_D(0);
            }
        }
    }


}

int Scheduler::getTimeStep()
{
    return TimeStep;
}

//LinkedQueue Scheduler::getNew()
//{
    //return Queue();
//}

void Scheduler::Stealing()
{

}

void Scheduler::CreateProcessor()
{
    for (int i = 1; i < NF + 1; i++)
    {
        FCFS_Processor* P1 = new FCFS_Processor(this);
        P1->setID(i);
        processor[i] = P1;

    }
    for (int i = NF + 1; i < (NS + NF) + 1; i++)
    {
        SJF* P2 = new SJF(this);
        P2->setID(i);
        processor[i] = P2;
    }
    for (int i = (NS + NF) + 1; i < (NR + NF + NS) + 1; i++)
    {
        RR_Processor* P1 = new RR_Processor(this);
        P1->setID(i);
        processor[i] = P1;
    }

}

void Scheduler::Load()
{
    ifstream Input;
    Input.open("ReadMe1.txt", ios::in);
    if (Input.is_open())
    {
        Input >> NF >> NS >> NR;
        Input >> TimeSlice;
        Input >> RTF >> MaxW >> STL >> ForkProbability;
        Input >> NumberOfProcesses;
        //cout << NF << " " << NS << " " << NR << '\n' << TimeSlice << '\n' << RTF << " " << MaxW << " " << STL << " " << ForkProbability << '\n' << NumberOfProcesses << '\n';
    }
    if (Input.is_open())
    {
        for (int j = 0; j < NumberOfProcesses; j++)
        {
            Process* ptr;
            ptr = new Process;
            int a, p, c,n;
            Input >> a >> p >> c >> n;
            ptr->setAT(a);
            ptr->setPID(p);
            ptr->setCT(c);
            ptr->setCT2(c);
            ptr->setN(n);
            NodeI_O* ptr2;
            ptr2 = new NodeI_O;
            //Input >> AT >> PID >> CT >> N;
            //cout << ptr->getAT() << " " << ptr->getPID() << " " << ptr->getCT() << " " << ptr->getN() << endl;
            int item1, item2;
            NodeI_O** arr;
            arr = new NodeI_O * [n];
            for (int i = 0; i < n; i++)
            {
                arr[i] == NULL;
            }
            Input.ignore();
            for (int i = 0; i < ptr->getN(); i++)
            {
                Input.ignore();
                Input >> item1;
                Input.ignore();
                Input >> item2;
                Input.ignore();
                NodeI_O store;
                store.setItem(item1, item2);
                arr[i] = &store;
                //cout << "(" << store.getItem() << "," << store.getItem2() << ")";
                //if (i == N)
                //{
                    //Input.ignore();
                //}
            }

            // cout << endl;

            ptr->setI_O(arr);
            AddNew(ptr);
        }

        //for (int y = 0; y < NumberOfProcesses; y++)
        //{
            //cout << ptr-> << " " << PID << " " << CT << " " << N << '\n';
            //for (int k = 0; k < N; k++)
            //{
                //cout << "(" << IO_R[k] << "," << IO_D[k] << ")";
            //}
            //cout << endl;
        //}

    }
    /*if (Input.is_open())
    {
        while (Input >> num1)
        {
            Input >> num2;
            cout << num1 << " " << num2 << endl;
        }*/
        //}
    Input.close();
    //Input_.close();
    //else??? 

}
void Scheduler::Forking(Process* F)
{
    srand(TimeStep);
    double fork = rand() % 100; //generate a random forking probability
    if (fork > 0 && fork < ForkProbability && Forkc == 0)
    {
        for (int i = 0; i < (NF + NS + NR); i++)
        {
            if (processor[i]->getRun() == F && (F->getCT() > 1))
            {
                if (processor[i]->getName() == "FCFS_P")
                {
                    if (processor[i]->getSchedulingState() == true)
                    {
                        Process* child = new Process;
                        child->setCT(F->getCT());
                        child->setPID(NumberOfProcesses++);
                        child->setAT(TimeStep);
                        int SI = ShortestFCFS();
                        processor[SI]->EnqueueReady(child);
                        Forkc = 1;
                        child->setORPH(false);
                        F->setORPHAN(child);
                    }
                }
            }
        }
    }
}
int Scheduler::getsleep()
{
    return sleep;
}
Process* Scheduler::OrphanCheck()
{
    for (int i = 0; i < TRMCount; i++)
    {
        Process* T;
        TRM.dequeue(T);
        if (T->getORPHAN() != NULL)
        {
            return T->getORPHAN();
            TRM.enqueue(T);
            break;
        }
        TRM.enqueue(T);
    }
}
int Scheduler::getNF()
{
    return NF;
}
void Scheduler::KILLSIG()
{
    FCFS_Processor* k = new FCFS_Processor(this);
    for (int i = 0; i < NF; i++)
    {

        k->KILL();
        if (k->KILL() == true)
        {
            SIGKILLCount++;
        }

    }
}
bool Scheduler::isProcessorBusy(int processorIndex) const
{
    // Check if the processor at the given index is busy
    return processor[processorIndex]->getRun() != nullptr;
}

void Scheduler::handleProcessMigration(Process& process, Scheduler& scheduler, int* RTF, int* MaxW)
{
    // Check if the process is in the RUN state and needs migration
    if (process.getRUN())
    {
        // Find an available processor to migrate the process
        for (int i = 0; i < NF; i++)
        {
            if (!scheduler.isProcessorBusy(i))
            {
                scheduler.processor[i]->MoveToRun(); // Move the process to the available processor's RUN queue
                process.setRUN(false); // Update the process state
                process.setNEW(true); // Set the process as new to be scheduled
                break;
            }
        }
    }
}

void Scheduler::migrateToSJF(Process& process, Scheduler& scheduler)
{
    // Check if the process has remaining time less than RTF threshold
    if (process.getRT() <= RTF)
    {
        // Move the process to SJF queue (index 1)
        scheduler.MoveToRDY(1);
        scheduler.handleProcessMigration(process, scheduler, nullptr, nullptr);
    }
}

void Scheduler::migrateToRR(Process& process, Scheduler& scheduler)
{
    // Check if the process total waiting time is greater than MaxW threshold
    if (process.getWT() > MaxW)
    {
        // Move the process to RR queue (index 0)
        scheduler.MoveToRDY(0);
        scheduler.handleProcessMigration(process, scheduler, nullptr, nullptr);
    }
}

void Scheduler::fcfsRRMigration()
{
    // Migrate processes from FCFS to RR or RR to SJF queue
    for (int i = 0; i < NR; i++)
    {
        Process* process = processor[i]->getRun();
        if (process != nullptr)
        {
            if (processor[i]->getName() == "RR")
            {
                migrateToSJF(*process, *this); // Migrate RR process to SJF queue
            }
            else if (processor[i]->getName() == "FCFS")
            {
                migrateToRR(*process, *this); // Migrate FCFS process to RR queue
            }
        }
    }
}

// Function to perform work stealing based on load balancing criteria
void Scheduler::workStealing()
{
    // Find the shortest and longest ready queues
    int shortestQueueIndex = 0;
    int longestQueueIndex = 0;
    int shortestQueueFinishTime = INT_MAX;
    int longestQueueFinishTime = INT_MIN;

    for (int i = 0; i < NR; i++)
    {
        int queueFinishTime = processor[i]->getExpectedFinishTime();
        if (queueFinishTime < shortestQueueFinishTime)
        {
            shortestQueueFinishTime = queueFinishTime;
            shortestQueueIndex = i;
        }
        if (queueFinishTime > longestQueueFinishTime)
        {
            longestQueueFinishTime = queueFinishTime;
            longestQueueIndex = i;
        }
    }

    // Calculate StealLimit
    double stealLimit = (longestQueueFinishTime - shortestQueueFinishTime) / (double)longestQueueFinishTime;

    // Check if StealLimit is greater than 40%
    if (stealLimit > 0.4)
    {
        // Calculate the number of processes to steal based on StealLimit
        int processesToSteal = ceil((stealLimit - 0.4) / 0.4);

        // Steal processes from the longest ready queue
        for (int i = 0; i < processesToSteal; i++)
        {
            Process* stolenProcess = nullptr;
            processor[longestQueueIndex]->dequeueRDY();
            processor[shortestQueueIndex]->EnqueueReady(stolenProcess);
        }

        // Recalculate StealLimit after stealing
        stealLimit = (longestQueueFinishTime - shortestQueueFinishTime) / (double)longestQueueFinishTime;

        // Check if StealLimit is still greater than 40% and steal more processes if necessary
        while (stealLimit > 0.4)
        {
            Process* stolenProcess = nullptr;
            processor[longestQueueIndex]->dequeueRDY();
            processor[shortestQueueIndex]->EnqueueReady(stolenProcess);

            stealLimit = (longestQueueFinishTime - shortestQueueFinishTime) / (double)longestQueueFinishTime;
        }
    }
}

void Scheduler::Output()
{
    fstream Output;
    Output.open("Output.txt", ios::out);
    if (Output.is_open())
    {
        int AvgU = 0;
        Output << "TT" << "  " << "PID" << "  " << "AT" << "  " << "CT" << "  " << "IO_D" << "   " << "WT" << "  " << "RT" << "  " << "TRT" << endl;
        while (!TRM.isEmpty())
        {
            Process* T;
            TRM.dequeue(T);
            WTSUM = WTSUM + (T->CalculateWT());
           RTSUM = RTSUM + (T->CalculateRT());
            TRTSUM = TRTSUM + (T->Calctrt());
            Output << T->getTT();
            if (T->getTT() < 10)
            {
                Output << "    ";
            }
            else if (T->getTT() < 100)
            {
                Output << "   ";
            }
            else
            {
                Output << "  ";
            }
            Output << T->getPID();
            if (T->getPID() < 10)
            {
                Output << "    ";
            }
            else if (T->getPID() < 100)
            {
                Output << "   ";
            }
            else
            {
                Output << "  ";
            }
            Output << T->getAT();
            if (T->getAT() < 10)
            {
                Output << "    ";
            }
            else if (T->getAT() < 100)
            {
                Output << "   ";
            }
            else
            {
                Output << "  ";
            }
            Output << T->getCT2();
            if (T->getCT2() < 10)
            {
                Output << "    ";
            }
            else if (T->getCT2() < 100)
            {
                Output << "   ";
            }
            else
            {
                Output << "  ";
            }
            Output << T->getTotalIO_D();
            if (T->getTotalIO_D() < 10)
            {
                Output << "    ";
            }
            else if (T->getTotalIO_D() < 100)
            {
                Output << "   ";
            }
            else
            {
                Output << "  ";
            }
            Output << T->CalculateWT();
            if (T->CalculateWT() < 10)
            {
                Output << "    ";
            }
            else if (T->CalculateWT() < 100)
            {
                Output << "   ";
            }
            else
            {
                Output << "  ";
            }
            Output << T->CalculateRT();
            if (T->CalculateRT() < 10)
            {
                Output << "    ";
            }
            else if (T->CalculateRT() < 100)
            {
                Output << "   ";
            }
            else
            {
                Output << "  ";
            }
            Output << T->CalculateTRT();
            if (T->CalculateTRT() < 10)
            {
                Output << "    ";
            }
            else if (T->CalculateTRT() < 100)
            {
                Output << "   ";
            }
            else
            {
                Output << "  ";
            }
            Output << endl;
        }
        Output << endl;
        Output << "Processes:" << " "<< NumberOfProcesses << endl; 
        Output << "Avg WT=" << " " << (WTSUM / NumberOfProcesses) << "," << " " << " " << "Avg RT=" << " " << (RTSUM / NumberOfProcesses) << "," << " " << " " << "Avg TRT=" << " " << (TRTSUM / NumberOfProcesses) << endl;
        Output << "Migration%:" << " " << " " << "RTF=" << " " << RTF << "%" << "," << " " << " " << "MaxW=" << " " << MaxW << "%" << endl;
        Output << "Work Steal%:" <<" " << "%" << endl; //calculate worksteal
        Output << "Forked Process:" << " " << "%" <<Forkc/NumberOfProcesses <<endl; //calculate
        Output << "Killed Process:" << " " <<"%"<<SIGKILLCount/NumberOfProcesses <<endl; //calculate
        Output << endl;
        Output << "Processors:" << " " << (NF + NS + NR) << " " << "[" << NF << " " << "FCFS" << "," << " " << NS << " " << "SJF" << "," << " " << NR << " " << "RR" << "]"<<endl;
        Output << "Processors Load" << endl;
        for (int i = 1; i < (NF + NR + NS) + 1; i++)
        {
            float x = processor[i]->CalculateLoad() / TRTSUM;
            //if(TRTSUM)
            Output << "p" << i << "=" <<x*100<< "%" << ", ";
        }
        Output << endl;
        Output << "Processors Utiliz" << endl;
        for (int i = 1; i < (NF + NR + NS) + 1; i++)
        {
            Output << "p" << i << "=" << processor[i]->CalculatePUtil()<< "%" << ", ";
            AvgU = AvgU + processor[i]->CalculatePUtil();
        }
        Output << endl;
        Output << "Avg utilization" << "=" << AvgU / (NF + NS + NR) << "%";
    }
}


//void Scheduler::PrintBLK()
//{
//    BLK.print(BLK);
//}

void Scheduler::CreateRunningArr()
{
    for (int i = 0; i < (NF + NS + NR); i++)
    {
        if (processor[i]->getRun() != NULL)
        {
            Running[i] = processor[i]->getRun();
        }
    }
}

bool Scheduler::IsTerminated()
{
    if (NumberOfProcesses == TRMCount)
    {
        return true;
    }
    else
        return false;
}

void Scheduler::IncrementRUNCount()
{
    RUNCount++;
}
