#pragma once
template <typename T>
class Node
{
private:
	T item;
	int priority;
	Node<T>* next;
public:
	Node();
	Node(const T& r_Item);
	Node(const T& r_Item, Node<T>* nextNodePtr);
	void setItem(const T& r_Item);
	void setNext(Node<T>* nextNodePtr);
	void setpriority(const int& value);
	T getItem() const;
	int getpriority();

	Node<T>* getNext() const;

};

template <typename T>
Node<T> ::Node()
{
	next = nullptr;
	priority = 0;
	item = 0;
}

template <typename T>
Node<T>::Node(const T& r_Item)
{
	item = r_Item;
	next = nullptr;
}

template<typename T>
Node<T>::Node(const T& r_Item, Node<T>* nextNodePtr)
{
	item = r_Item;
	next = nextNodePtr;
}

template <typename T>
void Node<T>::setItem(const T& r_Item)
{
	item = r_Item;
}
template <typename T>
void Node<T>::setNext(Node<T>* nextNodePtr)
{
	next = nextNodePtr;
}

template <typename T>
void Node<T>::setpriority(const int& value)
{
	priority = value;
}

template<typename T>
T Node<T>::getItem() const
{
	return item;
}

template <typename T>
Node<T>* Node<T>::getNext() const
{
	return next;
}

template <typename T>
int Node<T>::getpriority()
{
	return priority;
}

