#include "SJF.h"
#include "Processor.h"
#include"Scheduler.h"
#include <iostream>

SJF::SJF(Scheduler* ptr) :Processor(ptr)
{
	pntr = ptr;
	name = "SJF";
}
void SJF::SchedulingAlgo()
{
	Process* p = Run;
	if (RDY_SJF.isEmpty() && getSchedulingState() == 0)
	{
		ProcessorIdleTime++;
		return;
	}
	if (!RDY_SJF.isEmpty() && getSchedulingState() == 0)
	{
		MoveToRun();
		setSchedulingState(1);
	}
	if ((RDY_SJF.isEmpty() && getSchedulingState() == 1) || (!RDY_SJF.isEmpty() && getSchedulingState() == 1))
	{
		int id = 0;
		int IO = Run->getIO_R(1);
		if (Run->getN() != 0)
		{
			if (IO + Run->getRT() == pntr->getTimeStep())
			{
				MoveToBLK(Run);
				Run == NULL;
				setSchedulingState(0);
			}
		}
		if (Run->getRT() == 0)
		{
			Run->setRT(pntr->getTimeStep(), Run->getAT());
		}
		else if (Run->getRT() != 0)
		{
			Run->DecrementCT();
			ProcessorBusyTime++;
			setSchedulingState(1);
		}
		if (Run->getCT() == 0)
		{
			Run == NULL;
			setSchedulingState(0);
			//Run->setTRT();
			//Run->setWT();
			pntr->MoveToTRM(p);
		}

	}

	else
	{
		return;
	}
}


void SJF::EnqueueReady(Process* p)
{
	RDY_SJF.enqueue(p);
	RDYCount++;
	ExpectedFinishTime = ExpectedFinishTime + p->getCT();
}

void SJF::MoveToRun()
{

	Process* temp;//=null
	if (!RDY_SJF.isEmpty() && SchedulingState == 0)
	{
		RDY_SJF.dequeue(temp);
		Run = temp;
		SchedulingState = true;
		pntr->IncrementRUNCount();
		RDYCount--;
		return;
	}
	else
	{
		ProcessorIdleTime++;
		return;
	}
}
string SJF::getName()
{
	string n = "SJF_P";
	return n;
}

void SJF::PrintRDY()
{
	RDY_SJF.print();
}

Process* SJF::dequeueRDY()
{
	//RDY_SJF.dequeue(p); 
	return NULL;
}

Process* SJF::MoveToBLK(Process* p)
{
	return p;
	//or call the one that does that in scheduler
}

Process* SJF::MoveToTRM(Process* p)
{
	return p;
	//use one in scheduler
}

//void SJF::FindProcess(Process* temp)
//{
//
//}

bool SJF::KILL()
{
	return true;
}
