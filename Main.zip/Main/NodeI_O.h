#pragma once
class NodeI_O //:public Node <int>
{
private:
	int item;
	int item2;
public:
	NodeI_O();
	//NodeI_O(int& r_Item, int& r_Item2);
	void setItem(int& r_Item, int& r_Item2);
	int getItem() const;
	int getItem2() const;


};



