#ifndef _LINKEDLIST
#define _LINKEDLIST
/*#include <iostream>
using namespace std;*/
#include "Node.h"
#include "Process.h"
template <typename T>
class LinkedList
{
private:
	Node<T>* Head;	//Pointer to the head of the list
	//You can add tail pointer too (depending on your problem)
	int count = 0;
public:


	LinkedList()
	{
		Head = nullptr;
	}

	//List is being desturcted ==> delete all items in the list
	~LinkedList()
	{
		DeleteAll();
	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: PrintList.
	* prints the values of all nodes in a linked list.
	*/
	void PrintList()	const
	{
		cout << "\nprinting list contents:\n\n";
		Node<T>* p = Head;

		while (p)
		{
			cout << "[ " << p->getItem() << " ]";
			cout << "--->";
			p = p->getNext();
		}
		cout << "NULL\n";
	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: InsertBeg.
	* Creates a new node and adds it to the beginning of a linked list.
	*
	* Parameters:
	*	- data : The value to be stored in the new node.
	*/
	void InsertBeg(const T& data)
	{
		Node<T>* R = new Node<T>(data);
		R->setNext(Head);
		Head = R;
		count++;

	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: DeleteAll.
	* Deletes all nodes of the list.
	*/
	void DeleteAll()
	{
		Node<T>* P = Head;
		while (Head)
		{
			P = Head->getNext();
			delete Head;
			Head = P;
		}
	}
	bool isEmpty()
	{
		if (Head == NULL)
			return true;
		else
			return false;
	}

	/*Node<T>* getHead()
	{
		return Head;

	}*/
	void DeleteNode(T& data)
	{
		Node<T>* temp = Head;
		if (isEmpty())
			return;
		else if (!temp->getNext())
		{
			Head = Head->getNext();
			data = temp->getItem();
			delete temp;
			temp = nullptr;
		}
		else
		{
			while (temp->getNext()->getNext())
			{
				temp = temp->getNext();
			}
			data = (temp->getNext())->getItem();
			delete temp->getNext();
			temp->setNext(nullptr);
		}
	}
	int getCount()
	{
		return count;
	}
	void print()
	{
		Node<T>* temp = Head;
		Process* p = Head->getItem();
		while (temp)
		{
			cout << p->getPID() << " ";
			temp = temp->getNext();
		}
	}
	int Killing(int id)
	{
		Node<Process*>* temp = Head;
		while (temp)
		{
			if (id == (temp->getItem()->getPID()))
			{
				break;
			}
			temp = temp->getNext();
		}

		return id;
	}

	Node<T>* getHead()
	{
		return Head;

	}

	bool Remove(int position, T& returneditem) {
		bool ableToremove = position >= 1 && position <= getLength();
		if (ableToremove)
		{
			Node<T>* ptr = nullptr;
			if (position == 1)
			{
				ptr = Head;
				Head = Head->getNext();
			}
			else
			{
				Node<T>* prevPtr = getNodeAt(position - 1);
				ptr = prevPtr->getNext();
				prevPtr->setNext(ptr->getNext());
			}
			returneditem = ptr->getItem();
			ptr->setNext(nullptr);
			delete ptr;
			ptr = nullptr;

		}
		return ableToremove;
	}
	Node<T>* getNodeAt(int position)
	{
		if (!(position >= 1 && position <= getLength()))
		{
			return nullptr;
		}

		Node<T>* ptr = Head;
		for (int i = 1; i < position; i++)
		{
			ptr = ptr->getNext();
		}
		return ptr;
	}

	int getLength() {
		Node<T>* Trvrs = Head;
		int Ln = 0;
		while (Trvrs != nullptr) {
			Trvrs = Trvrs->getNext();
			Ln++;
		}
		return Ln;
	}
};

#endif