#pragma once
#include "LinkedQueue.h"
#include"Processor.h"
#include "RR_Processor.h"
#include "FCFS_Processor.h"
#include"SJF.h"
#include "UI.h"
class Scheduler
{
private:
	LinkedQueue<Process*> New;
	LinkedQueue<Process*> BLK;
	LinkedQueue<Process*> TRM; //queue? //order doesnt matter so linked list
	//is trm number in order?
	Processor** processor;
	UI* pntrToUI;
	int BLKCount;
	int TRMCount;
	int RUNCount;
	float StealLimit; //here?
	int TimeStep;
	int NF, NS, NR;
	int TimeSlice;
	float WTSUM, RTSUM, TRTSUM,trts;
	int N;
	int RTF, MaxW, STL, ForkProbability;
	//int ForkProbability;//float?
	int NumberOfProcesses; ///N???
	int  SIGKILLCount;
	//int SIGKILL here or ui?
	//int n; //number of processors? already 3ndy
	Process** Running;
	int IO_DCount;
	int Forkc;
	int sleep;
	//array of running processors here //processes wala processors??
public:
	Scheduler();
	void Forking(Process* F);
	int getsleep();
	Process* OrphanCheck();
	int getNF();
	void KILLSIG();
	bool isProcessorBusy(int processorIndex) const;
	void migrateToSJF(Process& process, Scheduler& scheduler);
	void migrateToRR(Process& process, Scheduler& scheduler);
	void handleProcessMigration(Process& process, Scheduler& scheduler, int* RTF, int* MaxW);
	void fcfsRRMigration();
	void workStealing();
	void AddNew(Process* p);
	bool MoveToRDY(int processorid); //revise
	int ChosenRDYList();
	int ShortestFCFS();
	void ShortestSJF();
	void ShortestRR();
	void MoveToBLK(Process* p);
	void MoveToTRM(Process* b);
	void DecrementTRM();
	void Simulate();
	void Simulate2();
	void IncrementBLKCount();
	void DecrementRUN();
	int getTimeSlice(); //allowed???
	void ChooseInterface(int x);
	void IncrementTRM();
	void testTRM();
	void RUNtoBLK(Process*a);
	void BLKtoRDY();
	int getTimeStep();
	//LinkedQueue<Process> getNew();
	//function that fills ready?
	//function that calls finish time of each processor (loops 3alehom) then sees which time is the shortest by calculating steallimit then moving process to
	//the rdy queue of that processor , sees which queue is longest too
	//so do all this, check on steal limit, then move it
	void Stealing();
	void CreateProcessor();
	void Load();
	void Output();
	//void PrintBLK();
	void CreateRunningArr();//itterate on each processor and add running process to it  and increment counter
	bool IsTerminated();
	void IncrementRUNCount();
	void DecrementTimeSlice();
	int random();
};

