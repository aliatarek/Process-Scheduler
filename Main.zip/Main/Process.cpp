#include "Process.h"
Process::Process()
{
	PID = 0;
	AT = 0;
	RT = 0;
	CT = 0;
	TT = 0;
	TRT = 0;
	WT = 0;
	N = 0;
	NEW = 0;
	RDY = 0;
	RUN = 0;
	BLK = 0;
	TRM = 0;
	ORPH = 0;
	Count = 0;
	flag = 0;
	TRMCount = 0;
	ORPHAN = NULL;
	REMAINTime = 0;
 //if condition
}
int Process::getPID() { return PID; }

void Process::setI_O(NodeI_O** arr)
{
	for (int i = 0; i < N; i++)
	{
		I_O.enqueue(*arr[i]);
	}
}

//void Process::setI_O(int a, int b)
//{
//	I_O(a);
//	I_O(b);
//}
void Process::setRemainingT(int x)
{
	REMAINTime = x;
}
void Process::setRT(int ts, int at)
{
	RT = ts - at;
}

int Process::getRemainingT()
{
	return REMAINTime;
}
void Process::setAT(int a)
{
	AT = a;
}

void Process::setCT2(int x)
{
	CT2 = x;
}

int Process::getCT2()
{
	return CT2;
}

void Process::setPID(int a)
{
	PID = a;
}

void Process::setCT(int a)
{
	CT = a;
}

void Process::setflag(int x)
{
	flag = x;
}

void Process::setN(int a)
{
	N = a;
}

void Process::DecrementN()
{
	N--;
}

void Process::setTT(int x)
{
	TT = x;
}


int Process::getN()
{
	return N;
}

float Process::Calctrt()
{
	if (TRT - 180 < 0)
		return (TRT - 190) * -1;
	else
		return TRT - 180;
}

int Process::getflag()
{
	return flag;
}

int Process::getAT()
{
	return AT;
}
int Process::getRT() { return RT; }
int Process::getCT() { return CT; }
int Process::getTT() { return TT; }

int Process::CalculateRT()
{
	if (flag - AT > 0)
		return flag - AT;
	else
		return -1 * (flag - AT);
}

int Process::CalculateTRT()
{
	if (TT - AT > 0)
		return TT - AT;
	else
		return -1 * (TT - AT);
}

int Process::CalculateWT()
{
	if (TRT - CT > 0)
		return TRT - CT;
	else
		return -1 * (TRT - CT);
}

void Process::setTRT()
{
	TRT = TT - AT;
}

void Process::setIO_R()
{

}

void Process::IncrementCount()
{
	Count++;
}

void Process::DecrementCount()
{
	Count--;
}

int Process::getTRT()
{
	return TRT;
}


void Process::setWT()
{
	WT = TRT - CT;
}

void Process::setCount(int a)
{
	Count = a;
}

int Process::getCount()
{
	return Count;
}


int Process::getWT()
{
	return WT;
}

void Process::setNEW(bool a)
{
	a = true;
}


bool Process::getNEW()
{
	return NEW;
}

void Process::setRDY(bool b)
{
	b = false;
}


bool Process::getRDY()
{
	return RDY;
}


void Process::setRUN(bool c)
{
	c = false;
}

bool Process::getRUN()
{
	return RUN;
}


void Process::setBLK(bool d)
{
	d = false;
}

bool Process::getBLK()
{
	return BLK;
}

void Process::setTRM(bool e)
{
	e = false;
}


bool Process::getTRM()
{
	return TRM;
}

void Process::setORPH(bool f)
{
	f = false;
}

bool Process::getORPH()
{
	return ORPH;
}

void Process::DecrementCT()
{
	CT--;
}

int Process::getIO_R(int x)
{
	NodeI_O n;
	NodeI_O s;
	if (x == 1)
	{
		I_O.peek(n);
		return n.getItem();
	}
	else if (x==0)
	{
		if (!I_O.isEmpty())
		{
			I_O.dequeue(n);
			return n.getItem();
		}
		else return 0;
	}
	/*else
		return n.getItem(); */
}

int Process::getIO_D(int x)
{
	NodeI_O n;
	NodeI_O s;
	if (x == 1)
	{
		I_O.peek(n);
		return n.getItem2();
	}
	else if (x == 0)
	{
		if (!I_O.isEmpty())
		{
			I_O.dequeue(n);
			return n.getItem2();
		}
		else return 0;
	}
}
void Process::setORPHAN(Process* O)
{
	ORPHAN = O;
}
Process* Process::getORPHAN()
{
	return ORPHAN;
}
int Process::getTotalIO_D()
{
	int total = 0;
	NodeI_O n;
	for (int i = 0; i < N; i++)
	{
		I_O.dequeue(n);
		total=total+ n.getItem2();
	}
	return total;
}

//void Process::ProcessLoad()
//{
	//ifstream Input;
	//Input.open("ReadMe.txt", ios::in);
	//if (Input.is_open())
//{
//	for (int j = 0; j < NumberOfProcesses; j++)
//		{
//			Process* ptr;
//			ptr = new Process;
//			int a, p, c, n;
//			Input >> a >> p >> c >> n;
//			ptr->setAT(a);
//			ptr->setPID(p);
//			ptr->setCT(c);
//			ptr->setN(n);
//			//NodeI_O* ptr2;
//			ptr2 = new NodeI_O;
//			//Input >> AT >> PID >> CT >> N;
//			cout << ptr->getAT() << ptr->getPID() << ptr->getCT() << ptr->getN();
//			int item1, item2;
//			NodeI_O** arr;
//			arr = new NodeI_O * [n];
//			for (int i = 0; i < n; i++)
//			{
//				arr[i] == NULL;
//			}
//			Input.ignore();
//			for (int i = 0; i < ptr->getN(); i++)
//			{
//				Input.ignore();
//				Input >> item1;
//				Input.ignore();
//				Input >> item2;
//				Input.ignore();
//				NodeI_O store;
//				store.setItem(item1);
//				store.setItem2(item2);
//				arr[i] = &store;
//				cout << store.getItem() << store.getItem2();
//				//if (i == N)
//				//{
//					//Input.ignore();
//				//}
//			}
//			ptr->setI_O(arr);
//		}
//		//for (int y = 0; y < NumberOfProcesses; y++)
//		//{
//			//cout << ptr-> << " " << PID << " " << CT << " " << N << '\n';
//			//for (int k = 0; k < N; k++)
//			//{
//				//cout << "(" << IO_R[k] << "," << IO_D[k] << ")";
//			//}
//			//cout << endl;
//		//}
//}

ostream& operator<<(ostream& a, Process& p)
{

	a << p.PID;
	return a;

}
