#include "RR_Processor.h"
#include"Scheduler.h"()
RR_Processor::RR_Processor(Scheduler* ptr):Processor(ptr)
{
	//initialize run??
	Timeslice = pntr->getTimeSlice();
	//IO = Run->getIO_R(0);
	//IO2 = Run->getIO_R(0);
}


void RR_Processor::SchedulingAlgo()
{
	Process* p;
	if (Run == NULL)
	{
		MoveToRun();
	}
	/*else
	{*/
		/*if (!RDY.isEmpty())
		{*/
			//int temp = pntr->getTimeSlice();
	if (Run != NULL) {
		/*if (IO == 0)
		{
			int IO = Run->getIO_R();
		}*/
		//int IO2 = Run->getIO_R();
		if (Run->getN() != 0 && Run->getIO_R(1) <= Timeslice)
		{
			Run->IncrementCount();
			ProcessorBusyTime++;
			Run->DecrementCT();
			//if (Run->getCount()==IO)
			//{
			//	Run->DecrementCount();
			//	//ptr->DecrementTimeSlice() 
			//	return;
			//}
			if (Run->getCT() == 0)
			{
				pntr->MoveToTRM(Run);
				pntr->IncrementTRM();
				//increment trmcount
				Run = NULL;
				SchedulingState = false;
				pntr->DecrementRUN();
				return;
				//decrement runcount
			}
		
			else if (Run->getCount() == Run->getIO_R(1))
			{
				//pntr->RUNtoBLK(Run);
				//pntr->IncrementBLKCount();
				//incrementblkcount
				pntr->MoveToTRM(Run);
				pntr->IncrementTRM();
				Run->getIO_R(0);
				Run->DecrementN();
				Run = NULL;
				SchedulingState = false;
				//decrement runcount
				pntr->DecrementRUN();
				return;
				
			}
			else
			{
				return;
			}
			/*RDY.dequeue(p);
			RDYCount--;
			Run = p;
			SchedulingState = true;*/
			//incrementruncount
		}
		//return?
		if (Run->getIO_R(1) > Timeslice || (Run->getN() == 0))
		{
			Run->IncrementCount();
			ProcessorBusyTime++;
			Run->DecrementCT();
			//while (Timeslice != 0)
			//{
			//	Timeslice--;
			//	//pntr->DecrementTimeSlice();
			//	return;
			//}
			if (Run->getCT() == 0 )
			{
				pntr->MoveToTRM(Run);
				pntr->IncrementTRM();
				//increment trmcount
				Run = NULL;
				SchedulingState = false;
				pntr->DecrementRUN();
				return;
				//decrement runcount
			}
			else
			{
				if (Run->getCount() == Timeslice)
				{
					if (Run->getCT() == 0)
					{
						if(Run!=NULL)
						pntr->MoveToTRM(Run);
						pntr->IncrementTRM();
						//increment trmcount
						Run = NULL;
						SchedulingState = false;
						pntr->DecrementRUN();
						return;
						//decrement runcount
					}
					else
					{
						RDY.enqueue(Run);
						RDYCount++;
						pntr->DecrementRUN();
						Run = NULL;
						//decrement runcount
						SchedulingState = false;
						return;
					}
					/*RDY.dequeue(p);
					RDYCount--;
					Run = p;
					SchedulingState = true;*/
				}
			}
			/*else
			{
				return;
			}*/

		}
		//}
	//}
	//io
	// at
	//actual scheduling
	//run count and blkcount
	//idle time??? busy too?
		/*if (Timeslice == 0)
		{
			Timeslice++;
		}*/
	}
 }
void RR_Processor::EnqueueReady(Process* p)
{
	//by reference?
	RDY.enqueue(p); //function in queue takes it by reference?
	ExpectedFinishTime = ExpectedFinishTime + p->getCT();
	RDYCount++;
}

void RR_Processor::MoveToRun()
{
	Process* temp;//=null
	if (!RDY.isEmpty() && SchedulingState == 0)
	{
		RDY.dequeue(temp);
		Run = temp;
		Run->setflag(getCurrentTimeStep());
		RDYCount--;
		SchedulingState = true;
		pntr->IncrementRUNCount();
		return;
	}
	else
	{
		ProcessorIdleTime++;
		return;
	}
}

void RR_Processor::PrintRDY()
{
	RDY.Print();
}

string RR_Processor::getName()
{
	string n = "RR_P";
	return n;
}
Process* RR_Processor::dequeueRDY()
{
	//RDY.dequeue(p);
	return NULL;
}

Process* RR_Processor::MoveToBLK(Process* p)
{
	return p;
	//or call the one that does that in scheduler
}

Process* RR_Processor::MoveToTRM(Process* p)
{
	return p;
	//use one in scheduler
}
bool RR_Processor::KILL()
{
	return true;
}

