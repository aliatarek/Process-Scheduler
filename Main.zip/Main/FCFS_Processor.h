#ifndef FCFS_PROCESSOR_H
#define FCFS_PROCESSOR_H
#include"LinkedList.h"
#include<string>
#include "Process.h"
#include "Processor.h"
#pragma once


class FCFS_Processor :public Processor
{
private:
	LinkedList<Process*>RDY;

	//Process* RUN;
	Process* RUN;
	LinkedQueue<NodeI_O> kill;
	LinkedQueue<int> KillTime;
	LinkedQueue<int> KillId;
	Scheduler* S;
	int timecount;
	int idcount;
public:
	FCFS_Processor(Scheduler* ptr);
	void SchedulingAlgo();
	void EnqueueReady(Process* p);
	void MoveToRun();
	void PrintRDY();
	string getName();
	void OrphKill();
	void Forking();
	Process* dequeueRDY();
	Process* MoveToBLK(Process* p);
	Process* MoveToTRM(Process* p);
	void LoadKILL();
	bool KILL();
	//void FindProcess(Process* temp);


};
#endif;


