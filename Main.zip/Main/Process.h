#pragma once
#include "NodeI_O.h"
#include "Queue.h"
#include"LinkedQueue.h"
#include <fstream>
class Process
{
private:
	int PID;
	int AT;
	int RT;
	int CT;
	int TT;
	int TRT;
	int WT;
	int N;
	bool NEW;
	bool RDY;
	bool RUN;
	bool BLK;
	bool TRM;
	bool ORPH;
	int Count;
	int IO_R;
	int flag;
	int CT2;
	int REMAINTime;
	int TRMCount;
	Process* ORPHAN;
	/*enum I_O
	{
		item1,item2
	}; */
	//NodeI_O** I_O;
	LinkedQueue<NodeI_O> I_O;
public:
	Process();
	void setRT(int ts, int at);
	void setRemainingT(int x);
	int getRemainingT();

	int getPID();
	int getIO_R(int x);
	int getIO_D(int x);
	void setI_O(NodeI_O** arr);
	int getTotalIO_D();
	//void setI_O(int a, int b);
	void setAT(int a);
	void setCT2(int x);
	int getCT2();
	void setPID(int a);
	void setCT(int a);
	void setflag(int x);
	void setN(int a);
	void DecrementN();
	void setTT(int x);
	int getN();
	float Calctrt();
	int getflag();
	int getAT();
	int getRT();
	int getCT();
	int getTT();
	int CalculateRT();
	int CalculateTRT();
	int CalculateWT();
	void setTRT();
	void setIO_R();
	void IncrementCount();
	void DecrementCount();
	int getTRT();
	void setWT();
	void setCount(int a);
	int getCount();
	int getWT();
	void setNEW(bool a);
	bool getNEW();
	void setRDY(bool b);
	bool getRDY();
	void setRUN(bool c);
	bool getRUN();
	void setBLK(bool d);
	bool getBLK();
	void setTRM(bool e);
	bool getTRM();
	void setORPH(bool f);
	bool getORPH();	
	void DecrementCT();
	//void ProcessLoad();
	void setORPHAN(Process* ORPH);
	Process* getORPHAN();
	friend ostream& operator<<(ostream& a, Process& p);
};
