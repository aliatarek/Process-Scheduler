#pragma once
#include "Processor.h"
#include "PriorityQueue.h"
#include<string>
class Scheduler;

class SJF :public Processor
{
private:
    PriorityQueue<Process*> RDY_SJF;
public:
    SJF(Scheduler* ptr);
    void SchedulingAlgo();
    void EnqueueReady(Process* p);
    void MoveToRun();
    Process* dequeueRDY();
    string getName();
    void PrintRDY();
    Process* MoveToBLK(Process* p);
    Process* MoveToTRM(Process* p);
    //void FindProcess(Process* temp);
    bool KILL();
};