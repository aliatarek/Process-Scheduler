#pragma once
#include "Queue.h"
#include<string>
#include "Process.h"
#include "Processor.h"
class Scheduler;
class RR_Processor :public Processor
{
private:
    LinkedQueue<Process*>RDY; //if it's empty, processor is idle    getter?
    int Timeslice;
    int IO;
    int IO2;
public:
    RR_Processor(Scheduler* ptr);
    void SchedulingAlgo();
    void EnqueueReady(Process* p);
    void MoveToRun(); //check implementation
    void PrintRDY();
    string getName();
    Process* dequeueRDY();
    Process* MoveToBLK(Process* p);
    Process* MoveToTRM(Process* p);
    bool KILL();
};
