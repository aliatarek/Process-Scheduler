#include "FCFS_Processor.h"
#include <iostream>
#include "Scheduler.h"

using namespace std;
FCFS_Processor::FCFS_Processor(Scheduler* ptr) :Processor(ptr)
{
	pntr = ptr;
	SchedulingState = false;
	Run = nullptr;
	name = "FCFS";
}
void FCFS_Processor::SchedulingAlgo()
{
	OrphKill();
	if (Run == NULL)
	{
		MoveToRun();
	}
	else
	{

		if (SchedulingState == 1)
		{
			Forking();
			Run = RUN;
			if (Run->getRT() == 0)
			{
				pntr->MoveToTRM(Run);
			}
			else if (((Run->getCT()) - (Run->getRT())) == Run->getIO_R(1))
				pntr->MoveToBLK(Run);
		}
	}
}
void FCFS_Processor::EnqueueReady(Process* p)
{
	RDY.InsertBeg(p);
	RDYCount++;
}
void FCFS_Processor::MoveToRun()
{
	if (!RDY.isEmpty() && SchedulingState == 0)
	{
		Process* p;
		RDY.DeleteNode(p);
		RUN = p;
		setSchedulingState(true);
		RDYCount++;
	}
	else
		ProcessorIdleTime++;
}
void FCFS_Processor::PrintRDY()
{
	RDY.print();
}
string FCFS_Processor::getName()
{
	string n = "FCFS_P";
	return n;
}

void FCFS_Processor::OrphKill()
{
	Process* orph = S->OrphanCheck();
	S->MoveToTRM(orph);
}
void FCFS_Processor::Forking()
{
	Process* parent = Run;
	S->Forking(parent);
}
Process* FCFS_Processor::dequeueRDY()
{
	Process* p;
	RDY.DeleteNode(p);
	RDYCount--;
	return p;
}

Process* FCFS_Processor::MoveToBLK(Process* p)
{
	return p;
}

Process* FCFS_Processor::MoveToTRM(Process* p)
{
	return p;
}

//void FCFS_Processor::FindProcess(Process * temp)
//{
//
//}

void FCFS_Processor::LoadKILL()
{
	ifstream Input;
	Input.open("ReadMe.txt", ios::in);
	if (Input.is_open())
	{
		string line;
		for (int i = 0; i < 3; i++) {
			getline(Input, line);
		}
		int x;
		Input >> x;
		for (int i = x; i < Input.eof(); i++)
		{
			int killtime;
			int killid;
			Input >> killtime >> killid;
			KillTime.enqueue(killtime);
			timecount++;
			KillId.enqueue(killid);
			idcount++;

		}
	}
	Input.close();
}

bool FCFS_Processor::KILL()
{
	int NF = pntr->getNF();
	int i;
	int j;
	int x;
	Process* a;
	while (NF > 0)
	{
		if (Run && (Run->getPID() == KillId.peek(x) && pntr->getTimeStep() == KillTime.peek(x)))
		{
			setRun(0);
			KillId.dequeue(i);
			KillTime.dequeue(j);
			Run = nullptr;

		}
		else
		{
			a = nullptr;
			Node<Process*>* temp = RDY.getHead();
			Process* killedProcess;
			int count = 1;
			while (temp)
			{
				for (int t = 0; t < timecount; t++)
				{
					if (pntr->getTimeStep() == KillTime.peek(t))
					{
						if (temp->getItem()->getPID() == KillId.peek(t))
						{
							ExpectedFinishTime = ExpectedFinishTime - a->getRemainingT();
							a->setTRT();
							TotalTRT = TotalTRT + a->getTRT();
							a->setWT();
							TotalWT = TotalWT + a->getWT();
							a->setRemainingT(0);
							KillTime.dequeue(i);
							KillId.dequeue(j);
							pntr->MoveToTRM(temp->getItem());
							RDY.Remove(count, killedProcess);
						}

					}

				}
				temp = temp->getNext();
				count++;
			}


		}

		NF--;
	}
	return true;
}

