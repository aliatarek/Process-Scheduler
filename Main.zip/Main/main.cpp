#include <iostream>
using namespace std;
#pragma once
#include<iostream>
#include"UI.h"
#include"Scheduler.h"
using namespace std;
int main()
{
	Scheduler* object = new Scheduler;
	object->Simulate2();
	//system("pause");
	//delete object;
	//object=NULL;
	object->Output();
	//object->testTRM();
}