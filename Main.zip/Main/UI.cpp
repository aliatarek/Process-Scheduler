#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include "UI.h"
#include "Scheduler.h"
using namespace std;


UI::UI()
{

}


void UI::InteractivePrint(int T, Processor** arr, int NF, int NS, int NR, LinkedQueue<Process*>BLK, int BLKCount, LinkedQueue<Process*>TRM, int TRMCount, int RUNCount, Process** Running)
{
	cout << "Current Timestep :" << T << endl;
	cout << "--------------------     RDY processes     --------------------" << endl;
	for (int i = 1; i < NF + 1; i++)
	{
		cout << "processor " << i << " [FCFS]: ";
		cout << arr[i]->getRDYCount() << "RDY: ";
		arr[i]->PrintRDY();
		cout << endl;

	}
	for (int i = NF + 1; i < (NS + NF) + 1; i++)
	{
		cout << "processor " << i << " [SJF]: ";
		cout << arr[i]->getRDYCount() << "RDY: ";
		arr[i]->PrintRDY();
		cout << endl;
	}
	for (int i = (NF + NS) + 1; i < (NR + NS + NF) + 1; i++)
	{
		cout << "processor " << i << " [RR]: ";
		cout << arr[i]->getRDYCount() << "RDY: ";
		arr[i]->PrintRDY();
		cout << endl;
	}

	cout << "--------------------     BLK processes     --------------------" << endl;
	cout << BLKCount;
	cout << " BLK: ";
	BLK.Print();
	cout << endl;
	cout << "--------------------     RUN processes     --------------------" << endl;
	cout << RUNCount;
	cout << "RUN: ";
	for (int i = 1; i < RUNCount + 1; i++)
	{
		if (arr[i]->getRun() != NULL)
		{
			cout << arr[i]->getRun()->getPID();
			//string x = arr[i]->getName();
			cout << "P" << "[" << i << "]" <<" ";
		}
		

	}
	//for (int i = 0; i < RUNCount; i++)
	//{
	//	cout << Running[i]->getID();  //last one will print, so use an if condition to stop that //need process to remove error
	//	if (i = RUNCount - 1)
	//	{
	//		cout << "";//break?
	//	}
	//	else
	//		cout << ",";
	//}
	cout << endl;
	cout << "--------------------     TRM processes     --------------------" << endl;
	cout << TRMCount; 
	cout << "TRM: ";
	//for (int i = 1; i < TRMCount + 1; i++)
	//{
		//if (TRM.peek())
		//{
			TRM.Print();
		//}


	//}
	//TRM.Print();
	cout << endl;
	cout << "PRESS ENTER TO MOVE TO NEXT STEP!";//enter
	cout << endl;
	while (1)
	{
		/*int x;
		cin >> x;*/
		if (cin.peek() == '\n')
		{
			break;
		}
	}
}

void UI::SilentPrint()
{
	cout << "Silent Mode.........       Simulation Starts....." << endl << "Simulation ends, Output file created";
	cout << endl;
}

void UI::StepByStepPrint(int T, Processor** arr, int NF, int NS, int NR, LinkedQueue<Process*>BLK, int BLKCount, LinkedQueue<Process*>TRM, int TRMCount, int RUNCount, Process** Running)
{
	cout << "Current Timestep :" << T << endl;
	cout << "--------------------     RDY processes     --------------------" << endl;
	for (int i = 1; i < NF + 1; i++)
	{
		cout << "processor " << i << " [FCFS]: ";
		cout << arr[i]->getRDYCount() << "RDY: ";
		arr[i]->PrintRDY();
		cout << endl;

	}
	for (int i = NF + 1; i < (NS + NF) + 1; i++)
	{
		cout << "processor " << i << " [SJF]: ";
		cout << arr[i]->getRDYCount() << "RDY: ";
		arr[i]->PrintRDY();
		cout << endl;
	}
	for (int i = (NF + NS) + 1; i < (NR + NS + NF) + 1; i++)
	{
		cout << "processor " << i << " [RR]: ";
		cout << arr[i]->getRDYCount() << "RDY: ";
		arr[i]->PrintRDY();
		cout << endl;
	}

	cout << "--------------------     BLK processes     --------------------" << endl;
	cout << BLKCount;
	cout << " BLK: ";
	BLK.Print();
	cout << endl;
	cout << "--------------------     RUN processes     --------------------" << endl;
	cout << RUNCount;
	cout << "RUN: ";
	for (int i = 1; i < RUNCount + 1; i++)
	{
		if (arr[i]->getRun() != NULL)
		{
			cout << arr[i]->getRun()->getPID();
			//string x = arr[i]->getName();
			cout << "P" << "[" << i << "]" << " ";
		}


	}
	//for (int i = 0; i < RUNCount; i++)
	//{
	//	cout << Running[i]->getID();  //last one will print, so use an if condition to stop that //need process to remove error
	//	if (i = RUNCount - 1)
	//	{
	//		cout << "";//break?
	//	}
	//	else
	//		cout << ",";
	//}
	cout << endl;
	cout << "--------------------     TRM processes     --------------------" << endl;
	cout << TRMCount;
	cout << "TRM: ";
	//for (int i = 1; i < TRMCount + 1; i++)
	//{
		//if (TRM.peek())
		//{
	TRM.Print();
	//}


//}
//TRM.Print();
	cout << endl;
	Sleep(1000);
}

int UI::Pick()
{
	cout << "For interactive Mode Press 1" << endl;;
	cout << "For Step-by-step Mode Press 2" << endl;;
	cout << "For Silent Mode Press 3"<<endl;
	int x;
	cin >> x;
	return x;
	{

	}
}
