#pragma once
#include "Node.h"
#include "Queue.h"
#include <vector>
#include <iostream>
#include "Process.h"
using namespace std;

template <typename T >
class PriorityQueue :public Queue<T>
{
private:
	Node<T>* backPtr;
	Node<T>* frontPtr;
	int priority;
public:
	PriorityQueue();
	bool isEmpty();
	bool enqueue(const T& newEntry);
	bool dequeue(T& frontEntry);
	bool peek(T& frontEntry);
	void print();
	~PriorityQueue();

};


template <typename T >
PriorityQueue<T>::PriorityQueue()
{
	backPtr = nullptr;
	frontPtr = nullptr;
	priority = 0;
}

template <typename T >
bool PriorityQueue<T>::isEmpty()
{
	return (frontPtr == nullptr);
}
template <typename T>
bool PriorityQueue<T>::enqueue(const T& newEntry)
{

	Process* p = newEntry;
	Node<T>* newNodeptr = new Node<T>(newEntry);
	Node<T>* ptr = new Node<T>;
	newNodeptr->setItem(newEntry);
	int value = p->getRemainingT();
	newNodeptr->setpriority(value);
	if (frontPtr == NULL || priority <= frontPtr->getpriority())
	{
		newNodeptr->setNext(frontPtr); //set instead of get?
		frontPtr = newNodeptr;
	}
	else
	{
		ptr = frontPtr;
		while (ptr->getNext() && priority >= ptr->getpriority())
		{
			ptr = ptr->getNext();
			newNodeptr->setNext(ptr->getNext());
			ptr->setNext(newNodeptr);
		}
	}
	return true;
}


template <typename T >
bool PriorityQueue<T>::dequeue(T& frontEntry)
{
	if (isEmpty())
		return false;
	Node<T>* nodeToDeletePtr = frontPtr;
	frontEntry = frontPtr->getItem();
	frontPtr = frontPtr->getNext();

	if (nodeToDeletePtr == backPtr)
		backPtr = nullptr;
	delete nodeToDeletePtr;
	return true;
}

template <typename T >
bool PriorityQueue<T>::peek(T& frontEntry)
{
	if (isEmpty())
		return false;
	frontEntry = frontPtr->getItem();
	return true;
}

template <typename T>
void PriorityQueue <T> ::print()
{
	T Pq;
	cout << "Priority Queue contents:";
	while (dequeue(Pq))
		cout << Pq << " ";
	cout << endl;
}

template <typename T >
PriorityQueue<T>::~PriorityQueue()
{
	T temp;
	while (dequeue(temp));
}


