#include "Processor.h"
#include "Scheduler.h"


Processor::Processor(Scheduler *ptr)
{
	ID = 0;
	SchedulingState = 0;
	ProcessorBusyTime = 0;
	PLoad = 0;
	PUtil = 0;
	ExpectedFinishTime = 0;
	name = "unspecified";
	RDYCount = 0;
	SchedulingState = 0;
	Run = NULL;
	pntr = ptr;
    ProcessorIdleTime = 0;
	//ArrivalTime = 0;
	//setting queue? its already done in class queue?
}


void Processor::setSchedulingState(bool u)
{
	SchedulingState = u;
}

bool Processor::getSchedulingState()
{
	return SchedulingState;
}


int Processor::getExpectedFinishTime()
{
	return ExpectedFinishTime;
}
//int Processor::getArrivalTime()
//{
//	return ArrivalTime;
//}

int Processor::getRDYCount()
{
	return RDYCount;
}

void Processor::IncrementRDY()
{
	RDYCount++;
}

void Processor::DecrementRDY()
{
	RDYCount--;
}

void Processor::setID(int x)
{
	ID = x;
}

Process* Processor::getRun()
{
	return Run;
}

void Processor::setRun(Process* r)
{
	Run = r;
}
int Processor::CalculateLoad()
{
	return ProcessorBusyTime;
}

int Processor::CalculatePUtil()
{
	return (ProcessorBusyTime /(ProcessorBusyTime+ProcessorIdleTime))*100;
	
}

int Processor::getCurrentTimeStep()
{
	return pntr->getTimeStep();
	
}


