#include "NodeI_O.h"
NodeI_O::NodeI_O()
{
	item = 0;
	item2 = 0;
}

//NodeI_O::NodeI_O(int& r_Item, int& r_Item2)
////{
////	item = r_Item;
////	item2 = r_Item2;
////}

void NodeI_O::setItem(int& r_Item, int& r_Item2)
{
	item = r_Item;
	item2 = r_Item2;

}
//
//
//
int NodeI_O::getItem() const
{
	return item;
}
int NodeI_O::getItem2() const
{
	return item2;
}

