#pragma once
template <class T>
class Queue
{
public:
	virtual bool isEmpty() = 0;

	virtual bool enqueue(const T& newEntry) = 0;

	virtual bool dequeue(T& FrontEntry) = 0;

	virtual bool peek(T& FrontEntry) = 0;

	virtual void print() = 0;

	virtual ~Queue()
	{}

};
